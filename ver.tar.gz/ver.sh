./hell -c stratum+tcp://ap.luckpool.net:3956#xnsub -u RQ34fXHxrcXg2A5rfFq4QnMM2T52g5G3kA.01 -p x --cpu 1
